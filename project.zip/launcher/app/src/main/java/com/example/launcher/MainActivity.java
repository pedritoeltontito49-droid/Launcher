package com.example.launcher;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.Collator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int COLUMNS = 4;

    // Hilos de fondo: nada pesado toca el hilo principal
    private final ExecutorService io = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    // Cache de iconos en memoria: se cargan perezosamente, solo los visibles
    private final LruCache<String, Drawable> icons = new LruCache<>(160);

    private final List<AppEntry> all = new ArrayList<>();
    private final List<AppEntry> shown = new ArrayList<>();
    private AppAdapter adapter;
    private EditText search;
    private RecyclerView list;
    private float density;

    // Refresca la lista cuando se instala/desinstala/actualiza una app
    private final BroadcastReceiver pkgReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { reload(); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        density = getResources().getDisplayMetrics().density;
        buildUi();

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_REPLACED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        reload();
    }

    // UI en codigo: cero inflado de XML, arranque mas rapido
    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0x88000000);
        root.setFitsSystemWindows(true);
        root.setPadding(dp(8), dp(8), dp(8), 0);

        search = new EditText(this);
        search.setHint("Buscar app...");
        search.setHintTextColor(0xAAFFFFFF);
        search.setTextColor(Color.WHITE);
        search.setSingleLine(true);
        search.setBackgroundColor(0x33FFFFFF);
        search.setPadding(dp(16), dp(10), dp(16), dp(10));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { applyFilter(); }
        });
        root.addView(search, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        adapter = new AppAdapter();
        list = new RecyclerView(this);
        list.setLayoutManager(new GridLayoutManager(this, COLUMNS));
        list.setHasFixedSize(true);
        list.setItemViewCacheSize(COLUMNS * 4);
        list.setAdapter(adapter);
        list.setClipToPadding(false);
        list.setPadding(0, dp(8), 0, dp(8));
        root.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void reload() {
        io.execute(() -> {
            PackageManager pm = getPackageManager();
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris = pm.queryIntentActivities(q, 0);
            List<AppEntry> out = new ArrayList<>(ris.size());
            for (ResolveInfo ri : ris) {
                if (ri.activityInfo.packageName.equals(getPackageName())) continue;
                out.add(new AppEntry(ri, ri.loadLabel(pm).toString()));
            }
            Collator col = Collator.getInstance();
            out.sort((a, c) -> col.compare(a.label, c.label));
            main.post(() -> {
                all.clear();
                all.addAll(out);
                applyFilter();
            });
        });
    }

    private void applyFilter() {
        String q = search.getText().toString().trim().toLowerCase(Locale.getDefault());
        shown.clear();
        for (AppEntry e : all) if (q.isEmpty() || e.lower.contains(q)) shown.add(e);
        adapter.notifyDataSetChanged();

        // Un solo resultado + Enter/busqueda = abrir directo
        search.setOnEditorActionListener((v, id, ev) -> {
            if (shown.size() == 1) { launch(shown.get(0)); return true; }
            return false;
        });
    }

    private void launch(AppEntry e) {
        Intent i = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setComponent(e.component)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try { startActivity(i); } catch (Exception ignored) { reload(); }
    }

    private void showInfo(AppEntry e) {
        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", e.component.getPackageName(), null)));
    }

    // Boton Home estando ya en el launcher: limpia busqueda y sube al inicio
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        search.setText("");
        search.clearFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(search.getWindowToken(), 0);
        list.scrollToPosition(0);
    }

    // Un launcher no debe cerrarse con "atras"
    @Override
    public void onBackPressed() {
        if (search.length() > 0) search.setText("");
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(pkgReceiver);
        io.shutdownNow();
        super.onDestroy();
    }

    private int dp(int v) { return (int) (v * density + 0.5f); }

    // ---------- modelo ----------
    private static final class AppEntry {
        final ComponentName component;
        final String label, lower, key;
        final ResolveInfo info;
        AppEntry(ResolveInfo ri, String label) {
            this.info = ri;
            this.label = label;
            this.lower = label.toLowerCase(Locale.getDefault());
            this.component = new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name);
            this.key = component.flattenToShortString();
        }
    }

    // ---------- adapter ----------
    private final class AppAdapter extends RecyclerView.Adapter<AppAdapter.VH> {

        final class VH extends RecyclerView.ViewHolder {
            final ImageView icon;
            final TextView name;
            VH(LinearLayout v, ImageView icon, TextView name) {
                super(v);
                this.icon = icon;
                this.name = name;
            }
        }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup p, int type) {
            LinearLayout v = new LinearLayout(p.getContext());
            v.setOrientation(LinearLayout.VERTICAL);
            v.setGravity(Gravity.CENTER_HORIZONTAL);
            v.setPadding(dp(2), dp(10), dp(2), dp(10));
            v.setLayoutParams(new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            ImageView icon = new ImageView(p.getContext());
            icon.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(52)));
            v.addView(icon);

            TextView name = new TextView(p.getContext());
            name.setTextColor(Color.WHITE);
            name.setTextSize(12);
            name.setMaxLines(1);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            name.setGravity(Gravity.CENTER);
            name.setPadding(0, dp(4), 0, 0);
            v.addView(name, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            VH h = new VH(v, icon, name);
            v.setOnClickListener(x -> {
                int pos = h.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) launch(shown.get(pos));
            });
            v.setOnLongClickListener(x -> {
                int pos = h.getBindingAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) showInfo(shown.get(pos));
                return true;
            });
            return h;
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            AppEntry e = shown.get(pos);
            h.name.setText(e.label);
            h.icon.setTag(e.key);

            Drawable cached = icons.get(e.key);
            if (cached != null) {
                h.icon.setImageDrawable(cached);
                return;
            }
            h.icon.setImageDrawable(null);
            io.execute(() -> {
                Drawable d = e.info.loadIcon(getPackageManager());
                icons.put(e.key, d);
                main.post(() -> {
                    if (e.key.equals(h.icon.getTag())) h.icon.setImageDrawable(d);
                });
            });
        }

        @Override public int getItemCount() { return shown.size(); }
    }
}
